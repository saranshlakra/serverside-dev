const cors = require('cors');
require('dotenv').config();
const express = require('express');
const axios = require('axios');
const app = express();
// const port = 5000;

app.use(cors());

app.get('/api/waldom/:partNumber', async (req, res) => {
    try {
        const { partNumber } = req.params;
        const response = await axios.get(`https://www.waldom.com/api/v1/${process.env.WALDOM_API_KEY}/ProductSearch/${partNumber}/0/1/1`, {
            headers: {
                // 'Authorization': `Bearer ${process.env.WALDOM_API_KEY}`
                'Authorization': `Bearer ${process.env.WALDOM_API_KEY}`

            }
        });
        console.log(response.data)
        res.json(response.data);
        console.log(response.data);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'An error occurred' });
    }
});

// app.listen(port, () => {
//     console.log(`Server running at http://localhost:${port}`);
// });


const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));